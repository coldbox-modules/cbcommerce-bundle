## [1.0.0] - 2022-09-05

* First iteration of this module
